import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class CommentTabWidget extends StatefulWidget {
  final Future<List<QueryDocumentSnapshot>> Function() fetchComments;
  final TextEditingController commentController;
  final double rating;
  final Function(double) setRating;
  final Function() submitComment;

  CommentTabWidget({
    required this.fetchComments,
    required this.commentController,
    required this.rating,
    required this.setRating,
    required this.submitComment,
  });

  @override
  _CommentTabWidgetState createState() => _CommentTabWidgetState();
}

class _CommentTabWidgetState extends State<CommentTabWidget> {
  late Future<List<QueryDocumentSnapshot>> commentsFuture;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    commentsFuture = widget.fetchComments();
  }

  Future<void> _refreshComments() async {
    setState(() {
      commentsFuture = widget.fetchComments();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          Text(
            "Leave a review",
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(height: 16),

          // RatingBar for setting rating
          Row(
            children: [
              Text(
                "Rate this recipe: ",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              RatingBar.builder(
                initialRating: widget.rating,
                minRating: 1,
                itemSize: 30,
                direction: Axis.horizontal,
                allowHalfRating: true,
                itemCount: 5,
                itemPadding: EdgeInsets.symmetric(horizontal: 2.0),
                itemBuilder: (context, _) =>
                    Icon(Icons.star, color: Colors.amber),
                onRatingUpdate: (rating) {
                  widget.setRating(rating); // Update rating
                },
              ),
            ],
          ),
          SizedBox(height: 16),

          // Comment input field
          TextField(
            controller: widget.commentController,
            decoration: InputDecoration(
              labelText: "Add your comment",
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
              ),
              contentPadding:
                  EdgeInsets.symmetric(vertical: 10, horizontal: 15),
              filled: true,
              fillColor: Colors.grey[100],
            ),
            maxLines: 3,
          ),
          SizedBox(height: 16),

          // Submit comment button
          ElevatedButton(
            onPressed: isLoading
                ? null
                : () async {
                    setState(() {
                      isLoading = true;
                    });
                    await widget.submitComment();
                    await _refreshComments(); // Refresh comments after submission
                    widget.commentController.clear(); // Clear input
                    widget.setRating(0.0); // Reset rating
                    setState(() {
                      isLoading = false;
                    });
                  },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: isLoading
                ? CircularProgressIndicator(color: Colors.white)
                : Text("Submit Comment", style: TextStyle(fontSize: 16)),
          ),
          SizedBox(height: 20),

          // Comments section
          Expanded(
            child: RefreshIndicator(
              onRefresh: _refreshComments, // Trigger only on pull-to-refresh
              child: FutureBuilder<List<QueryDocumentSnapshot>>(
                future: commentsFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Center(child: Text("Error loading comments"));
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return Center(child: Text("No comments yet"));
                  } else {
                    var comments = snapshot.data!;
                    return ListView.builder(
                      physics: AlwaysScrollableScrollPhysics(),
                      itemCount: comments.length,
                      itemBuilder: (context, index) {
                        var comment =
                            comments[index].data() as Map<String, dynamic>;
                        String username = comment['username'] ?? "Anonymous";
                        return ListTile(
                          contentPadding:
                              EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                          leading:
                              Icon(Icons.comment, color: Colors.blueAccent),
                          title: Text(
                            comment['comment'],
                            style: TextStyle(fontSize: 16),
                          ),
                          subtitle: Row(
                            children: [
                              Icon(Icons.star, color: Colors.amber, size: 16),
                              SizedBox(width: 4),
                              Text("${comment['rating']}",
                                  style: TextStyle(fontSize: 14)),
                            ],
                          ),
                          trailing: Text(
                            "by $username",
                            style: TextStyle(
                                fontSize: 12, fontStyle: FontStyle.italic),
                          ),
                          tileColor: Colors.grey[50],
                        );
                      },
                    );
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
