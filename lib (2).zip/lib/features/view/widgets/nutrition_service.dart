import 'dart:convert';
import 'package:http/http.dart' as http;

class NutritionService {
  final String appId = '3395c43c'; // Your Application ID
  final String appKey =
      'c68c88a890b47ba33311793c7830b28d'; // Your Application Key

  Future<Map<String, dynamic>?> analyzeRecipe(
      String recipeName, List<String> ingredients) async {
    final url = Uri.parse(
        'https://api.edamam.com/api/nutrition-details?app_id=$appId&app_key=$appKey');

    final body = json.encode({
      'title': recipeName,
      'ingr': ingredients,
    });

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: body,
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        print('Failed to analyze recipe: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }
}
