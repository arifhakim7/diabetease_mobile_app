import 'package:flutter/material.dart';

class RecipeAnalysisPage extends StatelessWidget {
  const RecipeAnalysisPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Retrieve the data passed via Navigator.pushNamed
    final Map<String, dynamic> arguments =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>;

    final double? glycemicIndex = arguments['glycemicIndex'];
    final double glucoseContent = arguments['glucoseContent'];

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text('Nutritional Information'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Nutritional Analysis',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
            ),
            SizedBox(height: 24.0),
            Text(
              'Glycemic Index: ${glycemicIndex != null ? glycemicIndex.toString() : 'N/A'}',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 12.0),
            Text(
              'Glucose Content: ${glucoseContent.toString()}g',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
