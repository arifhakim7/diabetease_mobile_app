import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:fyp_diabetease/features/app/splash_screen/splash_screen.dart';
import 'package:fyp_diabetease/features/view/layout/mainLayout.dart';
import 'package:fyp_diabetease/features/view/pages/admin/admin_homepage.dart';
import 'package:fyp_diabetease/features/view/pages/admin/manage_recipe.dart';
import 'package:fyp_diabetease/features/view/pages/admin/manage_user.dart';
import 'package:fyp_diabetease/features/view/pages/edit_profile_page.dart';
import 'package:fyp_diabetease/features/view/pages/login_page.dart';
import 'package:fyp_diabetease/features/view/pages/profile_page.dart';
import 'package:fyp_diabetease/features/view/pages/sign_up_page.dart';
import 'package:fyp_diabetease/features/view/pages/upload_recipe_page.dart';
import 'package:fyp_diabetease/features/view/pages/recipe_analysis_page.dart';
import 'package:fyp_diabetease/features/view/pages/inbox_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Diabetease',
      theme: ThemeData(
        primarySwatch: Colors.blue, // Set theme to blue
        primaryColor: Colors.blue,
        hintColor: Colors.blueAccent,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: Colors.blue, // Button text color
          ),
        ),
        appBarTheme: const AppBarTheme(
            backgroundColor: Colors.blue,
            titleTextStyle: TextStyle(color: Colors.white)),
      ),
      home: const SplashScreen(
        child: LoginPage(),
      ),
      debugShowCheckedModeBanner: false,
      routes: {
        'login_page': (context) => const LoginPage(),
        'sign_up_page': (context) => const SignUpPage(),
        'main_layout': (context) => const MainLayout(),
        'upload_recipe_page': (context) => const UploadRecipe(),
        'edit_profile_page': (context) => const EditProfilePage(),
        'profile_page': (context) => const ProfilePage(),
        'recipe_analysis': (context) => const RecipeAnalysisPage(),
        'homepage_recipe_details': (context) => const RecipeAnalysisPage(),
        //'homepage': (context) => const Homepage(),
        'inbox': (context) => const InboxPage(),
        'admin_homepage': (context) => const AdminHomepage(),
        'manage_users_page': (context) => const ManageUsersPage(),
        //'view_reports_page': (context) => const ViewReportsPage(),
        'manage_recipes_page': (context) => const ManageRecipesPage(),
      },
    );
  }
}
