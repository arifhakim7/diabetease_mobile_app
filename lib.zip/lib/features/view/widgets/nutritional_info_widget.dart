import 'package:flutter/material.dart';

// Your NutritionalInfoWidget code
class NutritionalInfoWidget extends StatelessWidget {
  final double calories;
  final double fat;
  final double sugar;
  final double protein;
  final double fiber;
  final double sodium;
  final double carbs;

  const NutritionalInfoWidget({
    Key? key,
    required this.calories,
    required this.fat,
    required this.sugar,
    required this.protein,
    required this.carbs,
    required this.fiber,
    required this.sodium,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Divider(thickness: 1.5),
            const Text(
              'Nutritional Information',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text('Calories: $calories kcal',
                style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text('Carbohydrates: $carbs g',
                style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text('Fiber: $fiber g', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text('Fat: $fat g', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text('Protein: $protein g', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text('Sodium: $sodium mg', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text('Added Sugar: $sugar g', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

// Main screen to display the NutritionalInfoWidget
class NutritionalInfoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // You can set these values dynamically based on your app's logic
    final double calories = 3734;
    final double fat = 240.4;
    final double sugar = 10.0;
    final double protein = 333.2;
    final double carbs = 999.2;
    final double sodium = 10.0;
    final double fiber = 10.0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Recipe Nutritional Information'),
      ),
      body: Center(
        child: NutritionalInfoWidget(
          calories: calories,
          carbs: carbs,
          fiber: fiber,
          fat: fat,
          protein: protein,
          sodium: sodium,
          sugar: sugar,
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: NutritionalInfoScreen(),
  ));
}
