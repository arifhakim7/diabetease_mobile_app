import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;

class EditRecipeForm extends StatefulWidget {
  final QueryDocumentSnapshot recipe;
  final Future<void> Function() onRecipeUpdated; // Define the callback

  const EditRecipeForm({required this.recipe, required this.onRecipeUpdated});

  @override
  _EditRecipeFormState createState() => _EditRecipeFormState();
}

class _EditRecipeFormState extends State<EditRecipeForm> {
  late TextEditingController _recipeNameController;
  late TextEditingController _descriptionController;
  late TextEditingController _ingredientsController;
  late TextEditingController _instructionsController;

  @override
  void initState() {
    super.initState();
    _recipeNameController =
        TextEditingController(text: widget.recipe['recipeName']);
    _descriptionController =
        TextEditingController(text: widget.recipe['description']);
    _ingredientsController =
        TextEditingController(text: widget.recipe['ingredients']);
    _instructionsController =
        TextEditingController(text: widget.recipe['instructions']);
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _recipeNameController,
            decoration: InputDecoration(labelText: 'Recipe Name'),
          ),
          TextField(
            controller: _descriptionController,
            decoration: InputDecoration(labelText: 'Description'),
          ),
          TextField(
            controller: _ingredientsController,
            decoration: InputDecoration(labelText: 'Ingredients'),
          ),
          TextField(
            controller: _instructionsController,
            decoration: InputDecoration(labelText: 'Instructions'),
          ),
          ElevatedButton(
            onPressed: () async {
              await _saveEditedRecipe(); // Save the recipe first
              widget.onRecipeUpdated(); // Refresh the recipe after saving
              Navigator.pop(context); // Close the dialog
            },
            child: Text('Save Changes'),
          ),
        ],
      ),
    );
  }

  // Function to save the edited recipe
  Future<void> _saveEditedRecipe() async {
    if (_recipeNameController.text.isEmpty ||
        _descriptionController.text.isEmpty ||
        _ingredientsController.text.isEmpty ||
        _instructionsController.text.isEmpty) {
      // Show an error message if the fields are empty
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please fill in all fields')),
      );
      return;
    }

    if (!mounted)
      return; // Check if the widget is still mounted before calling setState

    setState(() {});

    try {
      // Get ingredients and fetch nutritional information
      String ingredients = _ingredientsController.text;
      Map<String, dynamic> nutritionData =
          await _getNutritionalInfo(ingredients);

      double fat = nutritionData['FAT']?['quantity']?.toDouble() ?? 0.0;
      double carbohydrateContent =
          nutritionData['CHOCDF']?['quantity']?.toDouble() ?? 0.0;
      double fiberContent =
          nutritionData['FIBTG']?['quantity']?.toDouble() ?? 0.0;
      double sodiumContent =
          nutritionData['NA']?['quantity']?.toDouble() ?? 0.0;
      double calories =
          nutritionData['ENERC_KCAL']?['quantity']?.toDouble() ?? 0.0;
      double protein = nutritionData['PROCNT']?['quantity']?.toDouble() ?? 0.0;
      double addedSugars =
          nutritionData['SUGAR']?['quantity']?.toDouble() ?? 0.0;

      double riskLevel = _calculateRiskLevel(
        fat: fat,
        carbohydrateContent: carbohydrateContent,
        fiberContent: fiberContent,
        sodiumContent: sodiumContent,
      );

      // Update the recipe in Firestore
      await FirebaseFirestore.instance
          .collection('recipes')
          .doc(widget.recipe.id)
          .update({
        'recipeName': _recipeNameController.text,
        'description': _descriptionController.text,
        'ingredients': _ingredientsController.text,
        'instructions': _instructionsController.text,
        'calories': calories, // Store the updated nutritional values
        'fat': fat,
        'carbohydrateContent': carbohydrateContent,
        'fiberContent': fiberContent,
        'sodiumContent': sodiumContent,
        'protein': protein,
        'addedSugars': addedSugars,
        'riskLevel': riskLevel, // Update the risk level
      });

      if (!mounted) return; // Check again before calling setState

      setState(() {});

      Navigator.pop(context); // Close the dialog
    } catch (e) {
      if (!mounted) return; // Check again before calling setState

      setState(() {});
      print('Failed to update recipe: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to update recipe. Try again later.')),
      );
    }
  }

  // Function to fetch nutritional information from the Edamam API
  Future<Map<String, dynamic>> _getNutritionalInfo(String ingredients) async {
    const String appId = 'd1fb732f';
    const String appKey = '3f40152a27bade50b5e1c4144066352d';
    const String url = 'https://api.edamam.com/api/nutrition-data';

    List<String> ingredientList =
        ingredients.split('\n').map((ingredient) => ingredient.trim()).toList();
    Map<String, dynamic> totalNutrients = {};

    for (String ingredient in ingredientList) {
      try {
        final response = await http.get(
          Uri.parse('$url?app_id=$appId&app_key=$appKey&ingr=$ingredient'),
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data.containsKey('totalNutrients')) {
            data['totalNutrients'].forEach((key, value) {
              if (totalNutrients.containsKey(key)) {
                totalNutrients[key]['quantity'] += value['quantity'];
              } else {
                totalNutrients[key] = value;
              }
            });
          } else {
            throw Exception(
                'Nutritional information is missing for $ingredient');
          }
        } else {
          throw Exception('Failed to fetch nutritional info for $ingredient');
        }
      } catch (e) {
        print("Error fetching nutritional info for $ingredient: $e");
      }
    }

    return totalNutrients;
  }

  // Function to calculate the risk level
  double _calculateRiskLevel({
    required double fat,
    required double carbohydrateContent,
    required double fiberContent,
    required double sodiumContent,
  }) {
    double score = carbohydrateContent + fat;

    if (score <= 45) {
      return 1.0; // Low risk
    } else if (score > 45 && score <= 60) {
      return 2.0; // Medium risk
    } else {
      return 3.0; // High risk
    }
  }
}
