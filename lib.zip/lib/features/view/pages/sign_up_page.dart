import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fyp_diabetease/features/view/widgets/form_container_widget.dart';
import 'package:fyp_diabetease/features/view/widgets/dropdown_menu_widget.dart';
import 'package:intl/intl.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  String _selectedGender = "Male";
  String _selectedDiabetesType = "No Diabetes"; // Default diabetes type
  DateTime? _selectedDateOfBirth; // Updated to use DateTime

  @override
  void dispose() {
    _usernameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    super.dispose();
  }

  Future<void> _signUp() async {
    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );

      User? user = userCredential.user;

      if (user != null) {
        await _firestore.collection('users').doc(user.uid).set({
          'username': _usernameController.text,
          'email': _emailController.text,
          'dateOfBirth': _selectedDateOfBirth,
          'height': _heightController.text,
          'weight': _weightController.text,
          'gender': _selectedGender,
          'diabetesType': _selectedDiabetesType,
        });

        Navigator.pushReplacementNamed(context, 'main_layout');
      }
    } catch (e) {
      print("An error occurred: $e");
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDateOfBirth ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (pickedDate != null && pickedDate != _selectedDateOfBirth) {
      setState(() {
        _selectedDateOfBirth = pickedDate;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Sign Up",
                  style: TextStyle(
                    fontSize: 27,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
                SizedBox(height: 30),
                FormContainerWidget(
                  hintText: "Username",
                  isPasswordField: false,
                  controller: _usernameController,
                ),
                SizedBox(height: 10),
                FormContainerWidget(
                  hintText: "Email",
                  isPasswordField: false,
                  inputType: TextInputType.emailAddress,
                  controller: _emailController,
                ),
                SizedBox(height: 10),
                FormContainerWidget(
                  hintText: "Password",
                  isPasswordField: true,
                  controller: _passwordController,
                ),
                SizedBox(height: 10),
                GestureDetector(
                  onTap: () => _selectDate(context),
                  child: AbsorbPointer(
                    child: TextFormField(
                      decoration: InputDecoration(
                        labelText: "Date of Birth",
                        suffixIcon: Icon(Icons.calendar_today),
                      ),
                      controller: TextEditingController(
                        text: _selectedDateOfBirth != null
                            ? DateFormat('yyyy-MM-dd')
                                .format(_selectedDateOfBirth!)
                            : '',
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                FormContainerWidget(
                  hintText: "Height (cm)",
                  isPasswordField: false,
                  inputType: TextInputType.number,
                  controller: _heightController,
                ),
                SizedBox(height: 10),
                FormContainerWidget(
                  hintText: "Weight (kg)",
                  isPasswordField: false,
                  inputType: TextInputType.number,
                  controller: _weightController,
                ),
                SizedBox(height: 10),
                DropdownFormField(
                  hintText: "Gender",
                  value: _selectedGender,
                  onChanged: (String? newValue) {
                    setState(() {
                      _selectedGender = newValue!;
                    });
                  },
                  items: ["Male", "Female"],
                ),
                SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "Diabetes Type:",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(height: 5),
                DropdownFormField(
                  hintText: "Diabetes Type",
                  value: _selectedDiabetesType,
                  onChanged: (String? newValue) {
                    setState(() {
                      _selectedDiabetesType = newValue!;
                    });
                  },
                  items: [
                    "No Diabetes",
                    "Type 1",
                    "Type 2",
                    "Gestational",
                    "Other"
                  ],
                ),
                SizedBox(height: 30),
                GestureDetector(
                  onTap: _signUp,
                  child: Container(
                    width: double.infinity,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Text(
                        "Sign Up",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
