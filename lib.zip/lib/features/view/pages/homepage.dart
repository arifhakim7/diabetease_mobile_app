/*import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:fyp_diabetease/features/view/pages/homepageRecipeDetail.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  String? _username;
  String? _profileImageUrl;
  String? _dailyTip;
  List<String> _followedUserIds = []; // Store followed user IDs
  List<Map<String, dynamic>> _followedUserRecipes =
      []; // Store recipes from followed users

  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Timer to trigger every 24 hours
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _fetchUserDetails();
    _fetchDailyTip(); // Fetch the first tip immediately
    _startDailyTipTimer(); // Start the timer to fetch tip every 24 hours
  }

  // Fetch user details from Firestore
  Future<void> _fetchUserDetails() async {
    final currentUserId = FirebaseAuth.instance.currentUser!.uid;
    DocumentSnapshot userSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(currentUserId)
        .get();

    if (userSnapshot.exists) {
      setState(() {
        _username = (userSnapshot.data() as Map<String, dynamic>)['username'];
        _profileImageUrl =
            (userSnapshot.data() as Map<String, dynamic>)['profileImageUrl'];
      });

      // Fetch followed users' recipes after fetching user details
      _fetchFollowedUsersRecipes();
    } else {
      setState(() {
        _username = "Guest";
        _profileImageUrl = '';
      });
    }
  }

  // Fetch followed users' recipes
  Future<void> _fetchFollowedUsersRecipes() async {
    final currentUserId = FirebaseAuth.instance.currentUser!.uid;
    DocumentSnapshot userSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(currentUserId)
        .get();

    if (userSnapshot.exists) {
      // Get followed user IDs
      List<dynamic> followedUserIds =
          (userSnapshot.data() as Map<String, dynamic>)['followingUser'] ?? [];

      setState(() {
        _followedUserIds = List<String>.from(followedUserIds);
      });

      // Fetch recipes of followed users
      _fetchRecipesFromFollowedUsers();
    }
  }

  // Fetch recipes from followed users
  Future<void> _fetchRecipesFromFollowedUsers() async {
    List<Map<String, dynamic>> recipes = [];

    for (var userId in _followedUserIds) {
      QuerySnapshot recipesSnapshot = await FirebaseFirestore.instance
          .collection('recipes')
          .where('userId', isEqualTo: userId)
          .get();

      for (var recipeDoc in recipesSnapshot.docs) {
        recipes.add(recipeDoc.data() as Map<String, dynamic>);
      }
    }

    setState(() {
      _followedUserRecipes = recipes;
    });
  }

  // Fetch daily diabetes tip from OpenAI API using gpt-3.5-turbo-0125 model
  Future<void> _fetchDailyTip() async {
    const String apiKey =
        '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'; // Provide your API key
    final url = Uri.parse('https://api.openai.com/v1/chat/completions');

    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: json.encode({
        'model': 'gpt-3.5-turbo-0125', // Use the specified model
        'messages': [
          {
            'role': 'system',
            'content':
                'You are a helpful assistant providing daily tips for managing diabetes.'
          },
          {
            'role': 'user',
            'content': 'Give a daily tip for diabetes management.'
          }
        ],
        'max_tokens': 100,
        'temperature': 0.7,
      }),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      setState(() {
        _dailyTip = data['choices'][0]['message']['content'].trim();
      });
    } else {
      setState(() {
        _dailyTip = 'Sorry, we couldn\'t fetch the tip at the moment.';
      });
    }
  }

  // Start the timer to fetch a new tip every 24 hours
  void _startDailyTipTimer() {
    _timer = Timer.periodic(const Duration(hours: 24), (timer) {
      _fetchDailyTip();
    });
  }

  // Sign out the user
  Future<void> _logout() async {
    await _auth.signOut();
    Navigator.of(context).pushReplacementNamed(
        'login_page'); // Adjust the route to match your login page
  }

  // Navigate to profile page
  void _goToProfile() {
    Navigator.of(context).pushReplacementNamed('profile_page');
  }

  @override
  void dispose() {
    _timer?.cancel(); // Cancel the timer when widget is disposed
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _username != null ? 'Hi, $_username!' : 'Hi!',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            const Text(
              'What are you cooking today?',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
          ],
        ),
        actions: [
          GestureDetector(
            onTap: () {
              showMenu(
                context: context,
                position: RelativeRect.fromLTRB(
                  MediaQuery.of(context).size.width - 100,
                  60,
                  0,
                  0,
                ),
                items: [
                  const PopupMenuItem(
                    value: 'profile',
                    child: Row(
                      children: [
                        Icon(Icons.account_circle),
                        SizedBox(width: 10),
                        Text('My Profile'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'signOut',
                    child: Row(
                      children: [
                        Icon(Icons.logout),
                        SizedBox(width: 10),
                        Text('Sign Out'),
                      ],
                    ),
                  ),
                ],
                elevation: 8.0,
              ).then((value) {
                if (value == 'profile') {
                  _goToProfile(); // Navigate to profile page
                } else if (value == 'signOut') {
                  _logout(); // Sign out the user
                }
              });
            },
            child: CircleAvatar(
              radius: 24,
              backgroundImage:
                  _profileImageUrl != null && _profileImageUrl!.isNotEmpty
                      ? NetworkImage(_profileImageUrl!)
                      : const AssetImage('assets/images/avatar.png')
                          as ImageProvider,
              child: _profileImageUrl == null || _profileImageUrl!.isEmpty
                  ? const Icon(Icons.person) // Fallback icon if no avatar
                  : null,
            ),
          ),
          const SizedBox(width: 20),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 20),
            // Daily tip section wrapped in a rounded container
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    blurRadius: 5,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Daily Tip for Diabetes:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _dailyTip ?? 'Loading...',
                    style: const TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Display recipes from followed users
            if (_followedUserRecipes.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  'Recipes from People You Follow:',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 10),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _followedUserRecipes.length,
                itemBuilder: (context, index) {
                  var recipe = _followedUserRecipes[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    elevation: 5, // Add elevation for shadow
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(15), // Rounded corners
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(10),
                      leading: recipe['imageUrl'] != null
                          ? Image.network(
                              recipe['imageUrl'],
                              width: 80,
                              height: 80,
                              fit: BoxFit.cover,
                            )
                          : const Icon(Icons.restaurant_menu),
                      title: Text(
                        recipe['recipeName'] ?? 'Recipe Title',
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(recipe['username'] ?? 'Uploaded by User'),
                          const SizedBox(height: 5),
                        ],
                      ),
                      onTap: () {
                        Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              HomepageRecipeDetailPage(recipe: recipe)
                                        ),
                                      );
                      },
                    ),
                  );
                },
              ),
            ] else ...[
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  'You are not following anyone yet.',
                  style: TextStyle(fontSize: 16, color: Colors.grey),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}*/