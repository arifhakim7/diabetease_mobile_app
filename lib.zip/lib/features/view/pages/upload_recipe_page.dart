import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fyp_diabetease/firebase/firebase_service.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class UploadRecipe extends StatefulWidget {
  const UploadRecipe({Key? key}) : super(key: key);

  @override
  _UploadRecipeState createState() => _UploadRecipeState();
}

class _UploadRecipeState extends State<UploadRecipe> {
  final TextEditingController _recipeNameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _ingredientsController = TextEditingController();
  final TextEditingController _instructionsController = TextEditingController();
  final TextEditingController _prepTimeController = TextEditingController();
  final TextEditingController _cookTimeController = TextEditingController();
  final TextEditingController _servingController = TextEditingController();

  final FirebaseService _firebaseService = FirebaseService();

  XFile? _imageFile;
  bool _isLoading = false;

  final List<String> _tags = [
    "Breakfast",
    "Lunch",
    "Dinner",
    "Snacks",
    "Desserts",
    "Kidney-Friendly",
    "Vegan & Vegetarian",
    "Veggie-Rich",
    "Budget-Friendly",
    "Quich & Easy"
  ];
  List<String> _selectedTags = [];

  @override
  void dispose() {
    _recipeNameController.dispose();
    _descriptionController.dispose();
    _ingredientsController.dispose();
    _instructionsController.dispose();
    _prepTimeController.dispose();
    _cookTimeController.dispose();
    _servingController.dispose();
    super.dispose();
  }

  // Function to fetch nutritional information from the Edamam API
  Future<Map<String, dynamic>> _getNutritionalInfo(String ingredients) async {
    const String appId = 'd1fb732f';
    const String appKey = '3f40152a27bade50b5e1c4144066352d';
    const String url = 'https://api.edamam.com/api/nutrition-data';

    List<String> ingredientList =
        ingredients.split('\n').map((ingredient) => ingredient.trim()).toList();
    Map<String, dynamic> totalNutrients = {};

    for (String ingredient in ingredientList) {
      print("Fetching nutritional info for ingredient: $ingredient");
      try {
        final response = await http.get(
          Uri.parse('$url?app_id=$appId&app_key=$appKey&ingr=$ingredient'),
        );
        print(
            "API call URL: ${Uri.parse('$url?app_id=$appId&app_key=$appKey&ingr=$ingredient')}");

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data.containsKey('totalNutrients')) {
            data['totalNutrients'].forEach((key, value) {
              if (totalNutrients.containsKey(key)) {
                totalNutrients[key]['quantity'] += value['quantity'];
              } else {
                totalNutrients[key] = value;
              }
            });
          } else {
            throw Exception(
                'Nutritional information is missing in the response for $ingredient');
          }
        } else {
          throw Exception(
              'Failed to load nutritional information: ${response.reasonPhrase}');
        }
      } catch (e) {
        print("Error fetching nutritional info for $ingredient: $e");
      }
    }
    return totalNutrients;
  }

  // Function to upload the recipe
  Future<void> _uploadRecipe() async {
    if (_imageFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select an image')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      String ingredients = _ingredientsController.text;
      print("Ingredients input before splitting: $ingredients");
      Map<String, dynamic> nutritionData =
          await _getNutritionalInfo(ingredients);

      int serving = int.tryParse(_servingController.text) ?? 1;
      if (serving <= 0) serving = 1; // Avoid division by zero

      double glycemicIndex = 0.0;
      double glucoseContent =
          (nutritionData['SUGAR']?['quantity']?.toDouble() ?? 0.0) / serving;
      double carbohydrateContent =
          (nutritionData['CHOCDF']?['quantity']?.toDouble() ?? 0.0) / serving;
      double fiberContent =
          (nutritionData['FIBTG']?['quantity']?.toDouble() ?? 0.0) / serving;
      double sodiumContent =
          (nutritionData['NA']?['quantity']?.toDouble() ?? 0.0) / serving;
      double addedSugars =
          (nutritionData['SUGAR.added']?['quantity']?.toDouble() ?? 0.0) /
              serving;
      double calories =
          (nutritionData['ENERC_KCAL']?['quantity']?.toDouble() ?? 0.0) /
              serving;
      double fat =
          (nutritionData['FAT']?['quantity']?.toDouble() ?? 0.0) / serving;
      double protein =
          (nutritionData['PROCNT']?['quantity']?.toDouble() ?? 0.0) / serving;
      double sugar = glucoseContent;

      double riskLevel = _calculateRiskLevel(
        fat: fat,
        carbohydrateContent: carbohydrateContent,
        fiberContent: fiberContent,
        sodiumContent: sodiumContent,
      );

      String? imageUrl =
          await _firebaseService.uploadImage(File(_imageFile!.path));
      if (imageUrl == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Image upload failed')),
        );
        return;
      }

      await _firebaseService.uploadRecipe(
        recipeName: _recipeNameController.text,
        description: _descriptionController.text,
        ingredients: _ingredientsController.text,
        instructions: _instructionsController.text,
        imageUrl: imageUrl,
        calories: calories,
        fat: fat,
        sugar: sugar,
        protein: protein,
        glycemicIndex: glycemicIndex,
        carbohydrateContent: carbohydrateContent,
        fiberContent: fiberContent,
        sodiumContent: sodiumContent,
        addedSugars: addedSugars,
        riskLevel: riskLevel,
        tags: _selectedTags,
        prepTime: int.tryParse(_prepTimeController.text) ?? 0,
        cookTime: int.tryParse(_cookTimeController.text) ?? 0,
        serving: serving,
      );

      _showSuccessDialog();
    } catch (e) {
      print("An error occurred: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('An error occurred')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Function to calculate the risk level
  double _calculateRiskLevel({
    required double fat,
    required double carbohydrateContent,
    required double fiberContent,
    required double sodiumContent,
  }) {
    double score = carbohydrateContent;

    if (score <= 45) {
      return 1.0; // Low risk
    } else if (score > 45 && score <= 60) {
      return 2.0; // Medium risk
    } else {
      return 3.0; // High risk
    }
  }

  // Show success dialog
  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Success'),
          content: const Text('Recipe uploaded successfully!'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushNamed(context, 'profile_page');
              },
              child: const Text('View Your Recipe'),
            ),
          ],
        );
      },
    );
  }

  // Function to select image
  Future<void> _selectImage() async {
    final picker = ImagePicker();
    final pickedImage = await picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        _imageFile = pickedImage;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //automaticallyImplyLeading: false,
        title: const Text('Upload Recipe'),
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_imageFile != null) ...[
              Image.file(File(_imageFile!.path)),
              const SizedBox(height: 12.0),
            ],
            ElevatedButton(
              onPressed: _selectImage,
              child: const Text('Select Image'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
              ),
            ),
            const SizedBox(height: 24.0),
            TextField(
              controller: _recipeNameController,
              decoration: const InputDecoration(labelText: 'Recipe Name'),
            ),
            const SizedBox(height: 12.0),
            TextField(
              controller: _descriptionController,
              maxLines: null,
              decoration: const InputDecoration(labelText: 'Description'),
            ),
            const SizedBox(height: 12.0),
            TextField(
              controller: _ingredientsController,
              maxLines: null,
              decoration: const InputDecoration(labelText: 'Ingredients'),
            ),
            const SizedBox(height: 12.0),
            TextField(
              controller: _prepTimeController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  labelText: 'Preparation Time (minutes)'),
            ),
            const SizedBox(height: 12.0),
            TextField(
              controller: _cookTimeController,
              keyboardType: TextInputType.number,
              decoration:
                  const InputDecoration(labelText: 'Cooking Time (minutes)'),
            ),
            const SizedBox(height: 12.0),
            TextField(
              controller: _servingController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Servings'),
            ),
            const SizedBox(height: 12.0),
            TextField(
              controller: _instructionsController,
              maxLines: null,
              decoration: const InputDecoration(labelText: 'Instructions'),
            ),
            const SizedBox(height: 24.0),
            // Tag selection section
            const Text('Select Tags:', style: TextStyle(fontSize: 16.0)),
            Wrap(
              spacing: 8.0,
              children: _tags.map((tag) {
                return ChoiceChip(
                  label: Text(tag),
                  selected: _selectedTags.contains(tag),
                  onSelected: (isSelected) {
                    setState(() {
                      isSelected
                          ? _selectedTags.add(tag)
                          : _selectedTags.remove(tag);
                    });
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 24.0),
            _isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _uploadRecipe,
                    child: const Text('Upload Recipe'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
