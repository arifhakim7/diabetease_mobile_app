import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fyp_diabetease/features/view/widgets/form_edit_recipe_widget.dart';
import 'package:fyp_diabetease/features/view/widgets/risk_level_indicator_widget.dart';

class RecipeDetailPage extends StatefulWidget {
  final QueryDocumentSnapshot recipe;

  const RecipeDetailPage({Key? key, required this.recipe}) : super(key: key);

  @override
  _RecipeDetailPageState createState() => _RecipeDetailPageState();
}

class _RecipeDetailPageState extends State<RecipeDetailPage> {
  late Map<String, dynamic> recipeData;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    recipeData = widget.recipe.data() as Map<String, dynamic>;
    print('Recipe Data: $recipeData');
  }

  Future<void> _refreshRecipe() async {
    setState(() {
      _isLoading = true;
    });
    try {
      DocumentSnapshot refreshedRecipe = await FirebaseFirestore.instance
          .collection('recipes')
          .doc(widget.recipe.id)
          .get();
      setState(() {
        recipeData = refreshedRecipe.data() as Map<String, dynamic>;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to refresh recipe data: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        title: Text(
          recipeData['recipeName'] ?? 'No Recipe Name',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blueAccent,
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () => _showEditDialog(context, widget.recipe),
          ),
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => _showDeleteConfirmation(context, widget.recipe.id),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshRecipe,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildImageSection(),
                const SizedBox(height: 16.0),
                _buildSectionTitle('Description:'),
                _buildTextContent(
                    recipeData['description'] ?? 'No Description'),
                const SizedBox(height: 16.0),
                _buildSectionTitle('Tags:'),
                _buildTagsSection(),
                const SizedBox(height: 16.0),
                _buildSectionTitle('Ingredients:'),
                _buildTextContent(
                    recipeData['ingredients'] ?? 'No Ingredients'),
                const SizedBox(height: 16.0),
                _buildSectionTitle('Instructions:'),
                _buildTextContent(
                    recipeData['instructions'] ?? 'No Instructions'),
                const SizedBox(height: 16.0),
                _buildSectionTitle('Nutritional Analysis:'),
                _buildNutritionalAnalysis(),
                const SizedBox(height: 16.0),
                _buildSectionTitle('Risk Level:'),
                RiskLevelIndicatorWidget(
                    riskLevel: recipeData['riskLevel'] ?? 0),
                _isLoading
                    ? Center(child: CircularProgressIndicator())
                    : Container(),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showEditDialog(context, widget.recipe),
        backgroundColor: Colors.pink,
        child: const Icon(Icons.edit, color: Colors.white),
        elevation: 6.0,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      ),
    );
  }

  Widget _buildTagsSection() {
    List<String> tags = List<String>.from(recipeData['tags'] ?? []);
    return tags.isNotEmpty
        ? Wrap(
            spacing: 8.0,
            runSpacing: 4.0,
            children: tags.map((tag) {
              return Chip(
                label: Text(tag),
                backgroundColor: Colors.blueAccent,
                labelStyle: TextStyle(color: Colors.white),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.0),
                ),
              );
            }).toList(),
          )
        : Text('No tags available');
  }

  Widget _buildImageSection() {
    final imageUrl = recipeData['imageUrl'] ?? '';
    return imageUrl.isNotEmpty
        ? ClipRRect(
            borderRadius: BorderRadius.circular(12.0),
            child: Image.network(imageUrl,
                errorBuilder: (context, error, stackTrace) {
              return Icon(Icons.broken_image, size: 100, color: Colors.grey);
            }),
          )
        : Icon(Icons.image_not_supported, size: 100, color: Colors.grey);
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.blueGrey,
        ),
      ),
    );
  }

  Widget _buildTextContent(String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Text(
        content,
        style: const TextStyle(fontSize: 16),
      ),
    );
  }

  Widget _buildNutritionalAnalysis() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildNutritionalCard('Calories', recipeData['calories'], 'kcal'),
        _buildNutritionalCard(
            'Carbohydrates', recipeData['carbohydrateContent'], 'g'),
        _buildNutritionalCard('Fiber', recipeData['fiberContent'], 'g'),
        _buildNutritionalCard('Fat', recipeData['fat'], 'g'),
        _buildNutritionalCard('Protein', recipeData['protein'], 'g'),
        _buildNutritionalCard('Sodium', recipeData['sodiumContent'], 'mg'),
        _buildNutritionalCard('Added Sugars', recipeData['addedSugars'], 'g'),
      ],
    );
  }

  Widget _buildNutritionalCard(String label, dynamic value, String unit) {
    double displayValue = (value is num)
        ? value.toDouble()
        : double.tryParse(value.toString()) ?? 0.0;

    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: 4,
        color: Colors.blue[50],
        child: ListTile(
          title: Text(
            '$label: ${displayValue == 0.0 ? '-' : displayValue.toStringAsFixed(2)} $unit',
            style: TextStyle(fontSize: 16),
          ),
        ),
      ),
    );
  }

  void _showEditDialog(BuildContext context, QueryDocumentSnapshot recipe) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Edit Recipe'),
          content: EditRecipeForm(
            recipe: recipe,
            onRecipeUpdated: _refreshRecipe, // Pass the callback here
          ),
        );
      },
    );
  }

  void _showDeleteConfirmation(BuildContext context, String recipeId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Recipe'),
        content: const Text('Are you sure you want to delete this recipe?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => _deleteRecipe(context, recipeId),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _deleteRecipe(BuildContext context, String recipeId) {
    FirebaseFirestore.instance
        .collection('recipes')
        .doc(recipeId)
        .delete()
        .then((_) {
      Navigator.pop(context);
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Recipe deleted successfully')),
      );
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error deleting recipe: $error')),
      );
    });
  }
}
