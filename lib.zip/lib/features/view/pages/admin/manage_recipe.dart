import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ManageRecipesPage extends StatefulWidget {
  const ManageRecipesPage({Key? key}) : super(key: key);

  @override
  State<ManageRecipesPage> createState() => _ManageRecipesPageState();
}

class _ManageRecipesPageState extends State<ManageRecipesPage> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  // Predefined list of tags
  final List<String> _allTags = [
    "Salad",
    "Dessert",
    "Breakfast",
    "Dinner",
    "Vegetarian",
    "Vegan",
    "Gluten-Free",
    "Low-Carb",
    "Quick & Easy",
    "High-Protein",
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  /// Deletes a recipe from Firestore.
  Future<void> _deleteRecipe(String recipeId) async {
    try {
      await FirebaseFirestore.instance
          .collection('recipes')
          .doc(recipeId)
          .delete();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Recipe deleted successfully.')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to delete recipe: $e')),
      );
    }
  }

  /// Updates recipe information in Firestore.
  Future<void> _editRecipe(
      String recipeId, Map<String, dynamic> updatedData) async {
    try {
      await FirebaseFirestore.instance
          .collection('recipes')
          .doc(recipeId)
          .update(updatedData);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Recipe updated successfully.')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to update recipe: $e')),
      );
    }
  }

  /// Opens a dialog for editing a recipe.
  void _openEditDialog(String recipeId, Map<String, dynamic> recipeData) {
    final TextEditingController recipeNameController =
        TextEditingController(text: recipeData['recipeName'] ?? '');
    final TextEditingController descriptionController =
        TextEditingController(text: recipeData['description'] ?? '');
    final List<String> tags = List<String>.from(recipeData['tags'] ?? []);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Edit Recipe"),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: recipeNameController,
                  decoration: const InputDecoration(labelText: "Recipe Name"),
                  readOnly: true, // Make recipe name read-only
                ),
                TextField(
                  controller: descriptionController,
                  decoration: const InputDecoration(labelText: "Description"),
                  readOnly: true, // Make description read-only
                ),

                // Tags displayed as chips
                Wrap(
                  spacing: 5,
                  children: _allTags.map((tag) {
                    return ChoiceChip(
                      label: Text(tag),
                      selected: tags.contains(tag),
                      selectedColor: Colors
                          .blue, // Change the background color when selected
                      backgroundColor:
                          Colors.grey.shade200, // Default background color
                      labelStyle: TextStyle(
                        color: tags.contains(tag)
                            ? Colors.white
                            : Colors.black, // Change text color
                      ),
                      onSelected: (isSelected) {
                        setState(() {
                          if (isSelected) {
                            tags.add(tag);
                          } else {
                            tags.remove(tag);
                          }
                        });
                      },
                    );
                  }).toList(),
                )
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                final updatedData = {
                  'recipeName': recipeNameController.text.trim(),
                  'description': descriptionController.text.trim(),
                  'tags': tags,
                };
                _editRecipe(recipeId, updatedData);
                Navigator.pop(context);
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );
  }

  /// Retrieves a stream of recipes from Firestore.
  Stream<QuerySnapshot> _getRecipesStream() {
    final recipesCollection = FirebaseFirestore.instance.collection('recipes');
    if (_searchQuery.isEmpty) {
      return recipesCollection.snapshots();
    } else {
      return recipesCollection
          .where('recipeName', isGreaterThanOrEqualTo: _searchQuery)
          .where('recipeName', isLessThanOrEqualTo: '$_searchQuery\uf8ff')
          .snapshots();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Recipes"),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Search Bar
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: "Search by recipe name",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          setState(() {
                            _searchQuery = '';
                            _searchController.clear();
                          });
                        },
                      )
                    : null,
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value.trim();
                });
              },
            ),
            const SizedBox(height: 20),
            // Recipe List
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: _getRecipesStream(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return const Center(
                      child: Text('An error occurred while fetching recipes.'),
                    );
                  }

                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(
                      child: Text('No recipes found.'),
                    );
                  }

                  final recipes = snapshot.data!.docs;

                  return ListView.builder(
                    itemCount: recipes.length,
                    itemBuilder: (context, index) {
                      final recipe = recipes[index];
                      final recipeId = recipe.id;
                      final recipeData = recipe.data() as Map<String, dynamic>?;

                      final recipeName = recipeData?['recipeName'] ?? 'No name';
                      final username = recipeData?['username'] ?? 'Unknown';

                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundImage: NetworkImage(
                              recipeData?['imageUrl'] ?? '',
                            ),
                          ),
                          title: Text(recipeName),
                          subtitle: Text('Uploaded by: $username'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon:
                                    const Icon(Icons.edit, color: Colors.blue),
                                onPressed: () {
                                  _openEditDialog(recipeId, recipeData ?? {});
                                },
                              ),
                              IconButton(
                                icon:
                                    const Icon(Icons.delete, color: Colors.red),
                                onPressed: () async {
                                  final confirm = await showDialog(
                                    context: context,
                                    builder: (context) => AlertDialog(
                                      title: const Text("Delete Recipe"),
                                      content: const Text(
                                          "Are you sure you want to delete this recipe?"),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context, false),
                                          child: const Text("Cancel"),
                                        ),
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context, true),
                                          child: const Text("Delete"),
                                        ),
                                      ],
                                    ),
                                  );

                                  if (confirm == true) {
                                    _deleteRecipe(recipeId);
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
